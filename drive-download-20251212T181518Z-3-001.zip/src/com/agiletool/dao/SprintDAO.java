package com.agiletool.dao;

import com.agiletool.entity.sprint.Sprint;
import com.agiletool.database.Database;
import java.util.List;

public class SprintDAO {


    // Get a sprint by its ID
    public static Sprint getSprintById(int id) {
        for (int i = 0; i < Database.sprints.size(); i++) {
            Sprint sprint = Database.sprints.get(i);
            if (sprint.getId() == id) {
                return sprint;
            }
        }
        return null; // Sprint not found
    }


    // Get all sprints
    public static List<Sprint> getAllSprints() {
        return Database.sprints;
    }
}
