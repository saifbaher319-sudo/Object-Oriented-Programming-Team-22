package com.agiletool.dao;

import com.agiletool.database.Database;
import com.agiletool.entity.workitem.WorkItem;

import java.util.List;

public class WorkItemDAO {

    // getting workitem by its id
    public static WorkItem getWorkItemById(int id) {
        for (int i = 0; i < Database.workItems.size(); i++) {
            WorkItem workItem = Database.workItems.get(i);
            if (workItem.getId() == id) {
                return workItem;
            }
        }
        return null; // Not found
    }

    // Get all work items
    public static List<WorkItem> getAllWorkItems() {
        return Database.workItems;
    }
}
