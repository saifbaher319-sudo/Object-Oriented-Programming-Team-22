package com.agiletool.dao;

import com.agiletool.database.Database;
import com.agiletool.entity.user.User;

import java.util.List;

public class UserDAO {

    // Get user by ID
    public static User getUserById(int id) {
        for (int i = 0; i < Database.users.size(); i++) {
            User user = Database.users.get(i);
            if (user.getId() == id) {
                return user;
            }
        }
        return null; // Not found
    }

    // Get all users
    public static List<User> getAllUsers() {
        return Database.users;
    }
}
