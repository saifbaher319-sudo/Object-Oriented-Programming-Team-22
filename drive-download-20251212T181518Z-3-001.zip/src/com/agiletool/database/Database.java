package com.agiletool.database;

import com.agiletool.entity.sprint.Sprint;
import com.agiletool.entity.user.User;
import com.agiletool.entity.workitem.WorkItem;
import java.util.List;
import java.util.ArrayList;

public class Database {
    // Static lists for storing users, sprints, work items, etc.
    public static List<User> users = new ArrayList<>();
    public static List<Sprint> sprints = new ArrayList<>();
    public static List<WorkItem> workItems = new ArrayList<>();

    private static int userIdCounter = 1;
    private static int sprintIdCounter = 1;
    private static int workItemIdCounter = 1;

    // Method for generating unique user IDs
    public static int getNextUserId() {
        return userIdCounter++;
    }

    // Method for generating unique sprint IDs
    public static int getNextSprintId() {
        return sprintIdCounter++;
    }

    // Method for generating unique work item IDs
    public static int getNextWorkItemId() {
        return workItemIdCounter++;
    }

    // Method to add a new user to the users list
    public static void addUser(User user) {
        user.setId(getNextUserId());
        users.add(user);
    }

    // Method to add a new sprint to the sprints list
    public static void addSprint(Sprint sprint) {
        sprint.setId(getNextSprintId());
        sprints.add(sprint);
    }

    // Method to add a new work item to the workItems list
    public static void addWorkItem(WorkItem workItem) {
        workItem.setId(getNextWorkItemId());
        workItems.add(workItem);
    }
}
