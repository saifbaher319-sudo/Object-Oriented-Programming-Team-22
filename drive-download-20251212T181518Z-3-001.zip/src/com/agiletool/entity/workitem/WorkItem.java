package com.agiletool.entity.workitem;

import com.agiletool.entity.user.User;

public abstract class WorkItem {
    private int id;
    private String title;
    private String description;
    private String status;  // Store status as a String
    private User createdBy;
    private User assignedUser;  // The user assigned to this work item

    // Constructor
    public WorkItem(String title, String description, User createdBy) {
        this.title = title;
        this.description = description;
        this.createdBy = createdBy;
        this.status = "TODO";  // Default status set to "TODO"
    }

    // Getter and Setter for ID
    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    // Getter and Setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;  // Set status directly as a string
    }

    // Getter for title
    public String getTitle() {
        return title;
    }

    // Getter for createdBy (user who created the work item)
    public User getCreatedBy() {
        return createdBy;
    }

    // Getter and Setter for assignedUser
    public User getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(User assignedUser) {
        this.assignedUser = assignedUser;
    }

    // Method to assign this work item to a user
    public void assignToUser(User user) {
        this.assignedUser = user;
        // Ensure that the user has this work item in their work items list
        user.addWorkItem(this);  // Add the work item to the user's work items list
        System.out.println(this.title + " has been assigned to " + user.getName());
    }

    // Abstract method to be implemented by subclasses
    public abstract String getWorkItemType();
}
