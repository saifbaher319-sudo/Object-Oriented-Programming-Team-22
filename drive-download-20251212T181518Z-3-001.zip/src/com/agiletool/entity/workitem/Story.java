package com.agiletool.entity.workitem;

import com.agiletool.database.Database;
import com.agiletool.entity.user.User;
import java.util.List;
import java.util.ArrayList;

public class Story extends WorkItem {
    private List<Task> tasks;  // Tasks related to the Story (Subtasks)

    public Story(String title, String description, User createdBy, Epic parentEpic) {
        super(title, description, createdBy);  // Call to parent WorkItem constructor
        this.tasks = new ArrayList<>();  // Initialize the list of tasks

        //add to database
        Database.addWorkItem(this);
    }

    @Override
    public String getWorkItemType() {
        return "Story";
    }


    // Getter for tasks (subtasks)
    public List<Task> getTasks() {
        return tasks;
    }

    // Setter for tasks (subtasks)
    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    // Method to add a task to the story
    public void addTask(Task task) {
        if (!tasks.contains(task)) {  // Prevent duplicates
            tasks.add(task);
        }
    }

    // Method to update the status of the Story based on its Tasks
    public void updateStatus() {
        // Iterate through tasks and check if any task is not DONE
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);

            if (!task.getStatus().equals("DONE")) {
                this.setStatus("ACTIVE");  // If any task is not DONE, set story status to ACTIVE
                System.out.println("Story status is ACTIVE.");
                return;  // No need to check further if we found a task that's not done
            }
        }


        // If all tasks are DONE, set the Story status to DONE
        this.setStatus("DONE");
        System.out.println("Story status updated to DONE.");
    }

    // Method to get all work items (tasks in this case)
    public List<WorkItem> getAllWorkItems() {
        List<WorkItem> allWorkItems = new ArrayList<>();
        allWorkItems.addAll(tasks);  // Add all tasks to the list
        return allWorkItems;         // Return the combined list of work items
    }
}
