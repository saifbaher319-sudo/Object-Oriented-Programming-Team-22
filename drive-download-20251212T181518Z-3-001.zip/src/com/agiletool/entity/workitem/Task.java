package com.agiletool.entity.workitem;

import com.agiletool.database.Database;
import com.agiletool.entity.user.User;
import com.agiletool.entity.enums.TaskStatus;

public class Task extends WorkItem {
    private User assignedUser;

    // Constructor
    public Task(String title, String description, User createdBy, User assignedUser) {
        super(title, description, createdBy);  // Call to WorkItem constructor
        this.assignedUser = assignedUser;
        this.setStatus(TaskStatus.TODO.name());  // Use .name() to convert enum to String

        //add to database
        Database.addWorkItem(this);

    }

    @Override
    public String getStatus() {
        return super.getStatus();  // Get status through the getter from WorkItem
    }

    @Override
    public String getWorkItemType() {
        return "Task";  // Returns "Task" as the work item type
    }

    public User getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(User assignedUser) {
        this.assignedUser = assignedUser;
    }

    // Method to add this task to the assigned user's work items list
    public void assignToUser(User user) {
        this.assignedUser = user;
        user.addWorkItem(this);  // Add the task to the assigned user's work items list
    }
}
