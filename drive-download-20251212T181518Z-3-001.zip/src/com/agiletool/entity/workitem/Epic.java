package com.agiletool.entity.workitem;

import com.agiletool.entity.user.User;
import java.util.List;
import java.util.ArrayList;

public class Epic extends WorkItem {
    private List<Story> stories;  // Stories related to the Epic

    public Epic(String title, String description, User createdBy) {
        super(title, description, createdBy);  // Call to parent WorkItem constructor
        this.stories = new ArrayList<>();  // Initialize the list of stories
    }

    @Override
    public String getWorkItemType() {
        return "Epic";
    }

    // Getter for stories
    public List<Story> getStories() {
        return stories;
    }

    // Setter for stories
    public void setStories(List<Story> stories) {
        this.stories = stories;
    }

    // Method to add a story to the epic
    public void addStory(Story story) {
        if (!stories.contains(story)) {  // Prevent duplicates
            stories.add(story);
        }
    }

    // Method to get all work items (stories in this case)
    public List<WorkItem> getAllWorkItems() {
        List<WorkItem> allWorkItems = new ArrayList<>();
        allWorkItems.addAll(stories);  // Add all stories to the list
        return allWorkItems;           // Return the combined list of work items
    }

    // Method to manually update the status of the Epic based on its Stories
    public void updateStatus() {
        boolean allStoriesCompleted = true;

        // Check if all stories are completed
        for (Story story : stories) {
            if (!story.getStatus().equals("DONE")) {
                allStoriesCompleted = false;
                break;
            }
        }

        // Update epic status based on story completion
        if (allStoriesCompleted) {
            this.setStatus("DONE");
            System.out.println("Epic status updated to DONE.");
        } else {
            this.setStatus("ACTIVE");
            System.out.println("Epic status is ACTIVE.");
        }
    }


}
