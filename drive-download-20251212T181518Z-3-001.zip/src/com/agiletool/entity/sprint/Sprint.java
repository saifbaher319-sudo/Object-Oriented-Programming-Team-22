package com.agiletool.entity.sprint;

import com.agiletool.database.Database;
import com.agiletool.entity.workitem.Task;
import com.agiletool.entity.workitem.Bug;
import com.agiletool.entity.workitem.Epic;
import com.agiletool.entity.workitem.Story;
import com.agiletool.entity.user.User;
import com.agiletool.entity.workitem.WorkItem;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;

public class Sprint {
    private int id;                  // Sprint ID
    private String name;             // Sprint name
    private String objective;        // Sprint objective
    private List<Task> tasks;        // List of tasks assigned to the sprint
    private List<Bug> bugs;          // List of bugs assigned to the sprint
    private List<Story> stories;     // List of stories assigned to the sprint
    private List<Epic> epics;        // List of epics assigned to the sprint
    private List<User> teamMembers;  // Team members working on the sprint
    private LocalDate startDate;     // Start date of the sprint
    private LocalDate endDate;       // End date of the sprint
    private String status;           // Status of the sprint (ACTIVE, COMPLETED, CLOSED)
    private User createdBy;          // User who created the sprint

    // Constructor
    public Sprint(int id, String name, String objective, List<Task> tasks, List<Bug> bugs, List<Story> stories,
                  List<Epic> epics, List<User> teamMembers, LocalDate startDate, LocalDate endDate, String status, User createdBy) {
        this.id = id;
        this.name = name;
        this.objective = objective;
        this.tasks = tasks != null ? tasks : new ArrayList<>();
        this.bugs = bugs != null ? bugs : new ArrayList<>();
        this.stories = stories != null ? stories : new ArrayList<>();
        this.epics = epics != null ? epics : new ArrayList<>();
        this.teamMembers = teamMembers != null ? teamMembers : new ArrayList<>();
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.createdBy = createdBy;

        //add to database
        Database.addSprint(this);

    }

    // Getter and Setter methods for each attribute
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public List<Bug> getBugs() {
        return bugs;
    }

    public void setBugs(List<Bug> bugs) {
        this.bugs = bugs;
    }

    public List<Story> getStories() {
        return stories;
    }

    public void setStories(List<Story> stories) {
        this.stories = stories;
    }

    public List<Epic> getEpics() {
        return epics;
    }

    public void setEpics(List<Epic> epics) {
        this.epics = epics;
    }

    public List<User> getTeamMembers() {
        return teamMembers;
    }

    public void setTeamMembers(List<User> teamMembers) {
        this.teamMembers = teamMembers;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    // Method to add a work item (task, bug, story, or epic) to the sprint's backlog
    public void addWorkItemToBacklog(WorkItem workItem) {
        if (workItem instanceof Task) {
            this.tasks.add((Task) workItem);
            System.out.println("Task added to sprint.");
        } else if (workItem instanceof Bug) {
            this.bugs.add((Bug) workItem);
            System.out.println("Bug added to sprint.");
        } else if (workItem instanceof Story) {
            this.stories.add((Story) workItem);
            System.out.println("Story added to sprint.");
        } else if (workItem instanceof Epic) {
            this.epics.add((Epic) workItem);
            System.out.println("Epic added to sprint.");
        }
        addTeamMember(workItem.getAssignedUser());  // Add the assigned user to the sprint's team if not already added
    }

    // Method to add a team member to the sprint if not already added
    private void addTeamMember(User user) {
        if (!teamMembers.contains(user)) {
            teamMembers.add(user);
        }
    }

    // Method to update the sprint status based on the status of tasks, bugs, stories, and epics
    public void updateSprintStatus() {
        boolean allTasksAndBugsCompleted = true;

        // Check if all tasks are completed
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            if (!task.getStatus().equals("DONE")) {
                allTasksAndBugsCompleted = false;
                break;
            }
        }

// Check if all bugs are completed
        for (int i = 0; i < bugs.size(); i++) {
            Bug bug = bugs.get(i);
            if (!bug.getStatus().equals("DONE")) {
                allTasksAndBugsCompleted = false;
                break;
            }
        }

        // Check if all stories are completed
        for (int i = 0; i < stories.size(); i++) {
            Story story = stories.get(i);
            if (!story.getStatus().equals("DONE")) {
                allTasksAndBugsCompleted = false;
                break;
            }
        }

// Check if all epics are completed
        for (int i = 0; i < epics.size(); i++) {
            Epic epic = epics.get(i);
            if (!epic.getStatus().equals("DONE")) {
                allTasksAndBugsCompleted = false;
                break;
            }
        }

        // Update sprint status based on task/bug/story/epic completion
        if (allTasksAndBugsCompleted) {
            setStatus("COMPLETED");
        } else {
            setStatus("ACTIVE");
        }
    }

    // Method to display team members in the sprint
    public void displayTeamMembers() {
        System.out.println("Users in the sprint:");
        for (int i = 0; i < teamMembers.size(); i++) {
            User member = teamMembers.get(i);
            System.out.println(member.getName() + " - " + member.getRole());
        }
    }


    // Method to display work items (tasks, bugs, stories, and epics) in the sprint
    public void displayWorkItems() {
        System.out.println("Work items in the sprint:");

        // Display Tasks
        for (int i = 0; i < tasks.size(); i++) {
            Task task = tasks.get(i);
            System.out.println("Task: " + task.getTitle() + " - Status: " + task.getStatus());
        }

        // Display Bugs
        for (int i = 0; i < bugs.size(); i++) {
            Bug bug = bugs.get(i);
            System.out.println("Bug: " + bug.getTitle() + " - Status: " + bug.getStatus());
        }

        // Display Stories
        for (int i = 0; i < stories.size(); i++) {
            Story story = stories.get(i);
            System.out.println("Story: " + story.getTitle() + " - Status: " + story.getStatus());
        }

        // Display Epics
        for (int i = 0; i < epics.size(); i++) {
            Epic epic = epics.get(i);
            System.out.println("Epic: " + epic.getTitle() + " - Status: " + epic.getStatus());
        }
    }


    // Method to get all work items (tasks, bugs, stories, and epics) in the sprint
    public List<WorkItem> getWorkItems() {
        List<WorkItem> allWorkItems = new ArrayList<>();
        allWorkItems.addAll(tasks);  // Add all tasks to the list
        allWorkItems.addAll(bugs);   // Add all bugs to the list
        allWorkItems.addAll(stories); // Add all stories to the list
        allWorkItems.addAll(epics);   // Add all epics to the list
        return allWorkItems;         // Return the combined list
    }
}
