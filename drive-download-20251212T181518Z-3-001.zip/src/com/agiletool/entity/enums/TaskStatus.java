package com.agiletool.entity.enums;

public enum TaskStatus {
    TODO,              // Task is in the TODO state
    IN_PROGRESS,       // Task is being worked on
    READY_FOR_TEST,    // Task is ready for testing
    DONE;              // Task is resolved or completed
}
