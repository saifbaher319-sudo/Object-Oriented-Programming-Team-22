package com.agiletool.entity.enums;

public enum BugStatus {
    TODO,              // Bug is in the TODO state
    IN_PROGRESS,       // Bug is being worked on
    READY_FOR_TEST,    // Bug is ready for testing
    DONE;              // Bug is resolved or completed
}
