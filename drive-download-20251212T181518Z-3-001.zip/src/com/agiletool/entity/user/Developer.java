package com.agiletool.entity.user;

public class Developer extends User {

    // Constructor
    public Developer(String name, String email, String password) {  // Removed maxCapacity
        super(name, email, password, "Developer");  // Pass the role ("Developer") to the super constructor
    }

    @Override
    public String getRoleName() {
        return "Developer";
    }
}
