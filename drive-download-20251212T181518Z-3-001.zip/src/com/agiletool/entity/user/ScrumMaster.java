package com.agiletool.entity.user;

public class ScrumMaster extends User {

    // Constructor
    public ScrumMaster(String name, String email, String password) {  // Removed maxCapacity
        super(name, email, password, "ScrumMaster");  // Pass the role ("ScrumMaster") to the super constructor
    }

    @Override
    public String getRoleName() {
        return "ScrumMaster";
    }
}
