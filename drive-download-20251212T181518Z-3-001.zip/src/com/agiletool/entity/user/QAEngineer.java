package com.agiletool.entity.user;

public class QAEngineer extends User {

    // Constructor
    public QAEngineer(String name, String email, String password) {  // Removed maxCapacity
        super(name, email, password, "QA");  // Pass the role ("QA") to the super constructor
    }

    @Override
    public String getRoleName() {
        return "QA";
    }
}
