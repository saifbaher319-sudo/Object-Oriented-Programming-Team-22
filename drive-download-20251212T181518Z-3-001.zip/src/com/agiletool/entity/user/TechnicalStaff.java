package com.agiletool.entity.user;

import com.agiletool.entity.sprint.Sprint;
import com.agiletool.entity.workitem.Epic;
import com.agiletool.entity.workitem.Story;
import com.agiletool.entity.workitem.Task;
import com.agiletool.database.Database;
import com.agiletool.entity.workitem.WorkItem;

import java.util.List;

public class Stakeholder extends User {

    // Constructor
    public Stakeholder(String name, String email, String password) {
        super(name, email, password, "Stakeholder");  // Pass the role ("Stakeholder") to the super constructor
    }

    @Override
    public String getRoleName() {
        return "Stakeholder";
    }

    // Method for Stakeholder to create an Epic (without user assignment)
    public Epic createEpic(String title, String description, User createdBy) {
        Epic epic = new Epic(title, description, createdBy);  // Create epic without assigning to any user
        Database.addWorkItem(epic);  // Add to the global work items list
        return epic;
    }

    // Method for Stakeholder to create a Story (without user assignment)
    public Story createStory(String title, String description, User createdBy) {
        Story story = new Story(title, description, createdBy, null);  // Create story without assigning to any user
        Database.addWorkItem(story);  // Add to the global work items list
        return story;
    }


    public void viewWorkItemsInSprint(Sprint sprint) {
        System.out.println("Work items in Sprint: " + sprint.getName());
        List<WorkItem> workItems = sprint.getWorkItems();

        // Display only Epics and Stories for Stakeholder
        for (int i = 0; i < workItems.size(); i++) {
            WorkItem workItem = workItems.get(i);

            if (workItem instanceof Epic || workItem instanceof Story) {
                System.out.println(workItem.getWorkItemType() + ": "
                        + workItem.getTitle()
                        + " - Status: "
                        + workItem.getStatus());
            }
        }
    }

}
