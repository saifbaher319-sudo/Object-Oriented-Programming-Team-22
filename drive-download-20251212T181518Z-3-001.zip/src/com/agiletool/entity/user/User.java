package com.agiletool.entity.user;

import com.agiletool.entity.workitem.WorkItem;
import java.util.ArrayList;
import java.util.List;

public abstract class User {
    protected int id;
    protected String name;
    protected String email;
    protected String password;  // Plain-text password (simplified for this project)
    protected String role;  // Role (e.g., Developer, QA, etc.)
    protected List<WorkItem> workItems;  // List to store assigned tasks and bugs

    // Constructor
    public User(String name, String email, String password, String role) {  // Removed maxCapacity
        this.name = name;
        this.email = email;
        this.password = password;  // In a real app, password should be hashed
        this.role = role;
        this.workItems = new ArrayList<>();  // Initialize the list of work items
    }

    // Getter and Setter methods
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // ID related methods
    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    // Get the name of the user
    public String getName() {
        return name;
    }

    // Method to check the password
    public boolean checkPassword(String passwordToCheck) {
        return this.password.equals(passwordToCheck);  // Simple password comparison
    }

    // Abstract method that will be implemented by subclasses
    public abstract String getRoleName();

    // Method to get the work items assigned to this user
    public List<WorkItem> getWorkItems() {
        return workItems;  // Returns the list of tasks and bugs assigned to this user
    }

    public void addWorkItem(WorkItem workItem) {
        if (workItem != null && !this.workItems.contains(workItem)) {
            this.workItems.add(workItem);
        }
    }
}
