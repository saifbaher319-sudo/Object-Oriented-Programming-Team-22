package com.agiletool.main;

import com.agiletool.service.UserService;
import com.agiletool.service.TaskService;
import com.agiletool.dao.WorkItemDAO;
import com.agiletool.entity.workitem.Task;
import com.agiletool.entity.workitem.WorkItem;
import com.agiletool.entity.user.User;

public class Main {
    public static void main(String[] args) {

    }
}
