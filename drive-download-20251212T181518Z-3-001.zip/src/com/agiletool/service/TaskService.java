package com.agiletool.service;

import com.agiletool.entity.user.*;
import com.agiletool.entity.workitem.Task;
import com.agiletool.entity.workitem.Bug;
import com.agiletool.entity.workitem.Epic;
import com.agiletool.entity.workitem.Story;
import com.agiletool.entity.sprint.Sprint;
import com.agiletool.database.Database;
import com.agiletool.entity.workitem.WorkItem;

import java.util.List;

public class TaskService {

    // Create a task (Stakeholders can also create a task without assigning)
    public Task createTask(String title, String description, User createdBy) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return null;
        }

        Task task = new Task(title, description, createdBy, null);  // no user assignment

        // ID will be assigned automatically by Database.addWorkItem
        Database.addWorkItem(task);
        return task;
    }

    // Create a bug (Same as task)
    public Bug createBug(String title, String description, User createdBy) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return null;
        }

        Bug bug = new Bug(title, description, createdBy, null);

        Database.addWorkItem(bug);
        return bug;
    }

    // Create an Epic (without user assignment)
    public Epic createEpic(String title, String description, User createdBy) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return null;
        }

        Epic epic = new Epic(title, description, createdBy);

        Database.addWorkItem(epic);
        return epic;
    }

    // Create a Story (without user assignment)
    public Story createStory(String title, String description, User createdBy, Epic parentEpic) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return null;
        }

        Story story = new Story(title, description, createdBy, parentEpic);

        Database.addWorkItem(story);
        return story;
    }

    // Assign tasks and bugs to a sprint
    public void assignWorkItemsToSprint(Sprint sprint, List<Task> tasks, List<Bug> bugs) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return;
        }

        sprint.setTasks(tasks);
        sprint.setBugs(bugs);
        System.out.println("Work items assigned to the sprint.");
    }

    // Assign a work item (task or bug) to a user
    public void assignWorkItemToUser(WorkItem workItem, User assignedUser) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("You must be logged in to assign a work item.");
            return;
        }

        if (assignedUser == null) {
            System.out.println("Assigned user is null. Cannot assign work item.");
            return;
        }

        workItem.assignToUser(assignedUser);
        System.out.println(workItem.getTitle() + " assigned to " + assignedUser.getName());
    }

    // Add a Task to a Story (only ScrumMaster)
    public void addTaskToStory(Story story, Task task) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return;
        }

        User loggedInUser = UserService.getLoggedInUser();

        if (loggedInUser instanceof ScrumMaster) {
            story.addTask(task);
            story.updateStatus();
            System.out.println("Task: " + task.getTitle() + " added to Story: " + story.getTitle());
        } else {
            System.out.println("Only ScrumMaster can add tasks to stories.");
        }
    }

    // Add a Story to an Epic (only ScrumMaster)
    public void addStoryToEpic(Epic epic, Story story) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return;
        }

        User loggedInUser = UserService.getLoggedInUser();

        if (loggedInUser instanceof ScrumMaster) {
            epic.addStory(story);
            System.out.println("Story: " + story.getTitle() + " added to Epic: " + epic.getTitle());
        } else {
            System.out.println("Only ScrumMaster can add stories to epics.");
        }
    }

    // Update sprint status
    public void updateSprintStatus(Sprint sprint) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("Please log in first.");
            return;
        }

        sprint.updateSprintStatus();
    }
}
