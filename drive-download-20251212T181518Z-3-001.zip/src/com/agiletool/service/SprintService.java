package com.agiletool.service;

import com.agiletool.entity.sprint.Sprint;
import com.agiletool.entity.user.Developer;
import com.agiletool.entity.user.QAEngineer;
import com.agiletool.entity.workitem.*;
import com.agiletool.entity.user.User;
import com.agiletool.entity.enums.TaskStatus;
import com.agiletool.entity.enums.BugStatus;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SprintService {

    // Method to create a sprint (only accessible by ScrumMaster)
    public Sprint createSprint(String name, String objective, LocalDate startDate, LocalDate endDate) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("You must be logged in to create a sprint.");
            return null;
        }

        User loggedInUser = UserService.getLoggedInUser();

        if (!loggedInUser.getRole().equals("ScrumMaster")) {
            System.out.println("Only a ScrumMaster can create a sprint.");
            return null;
        }

        Sprint sprint = new Sprint(
                1,
                name,
                objective,
                new ArrayList<Task>(),
                new ArrayList<Bug>(),
                new ArrayList<Story>(),
                new ArrayList<Epic>(),
                new ArrayList<User>(),
                startDate,
                endDate,
                "ACTIVE",
                loggedInUser
        );

        addTeamMember(sprint, UserService.getLoggedInUser());

        return sprint;
    }

    // Method to update the task status
    public void updateTaskStatus(Sprint sprint, WorkItem workItem, String newStatus) {
        if (workItem instanceof Task) {
            Task task = (Task) workItem;
            User loggedInUser = UserService.getLoggedInUser();

            if (loggedInUser == null) {
                System.out.println("You must be logged in to update task status.");
                return;
            }

            if (task.getAssignedUser() == loggedInUser && loggedInUser instanceof Developer) {
                if (task.getStatus().equals(TaskStatus.TODO.name())) {
                    if (newStatus.equals(TaskStatus.IN_PROGRESS.name()) || newStatus.equals(TaskStatus.READY_FOR_TEST.name())) {
                        task.setStatus(newStatus);
                        System.out.println("Task status updated to " + newStatus + ".");
                    }
                } else if (task.getStatus().equals(TaskStatus.IN_PROGRESS.name())) {
                    if (newStatus.equals(TaskStatus.READY_FOR_TEST.name())) {
                        task.setStatus(TaskStatus.READY_FOR_TEST.name());
                        System.out.println("Task status updated to READY_FOR_TEST.");
                    }
                }
                //manages each users accessibility to change status

            } else if (loggedInUser instanceof QAEngineer && task.getStatus().equals(TaskStatus.TODO.name()) && newStatus.equals(TaskStatus.IN_PROGRESS.name())) {
                System.out.println("Only a Developer can move this task from TODO to IN_PROGRESS.");
            } else if (loggedInUser instanceof Developer && task.getStatus().equals(TaskStatus.READY_FOR_TEST.name()) && newStatus.equals(TaskStatus.DONE.name())) {
                System.out.println("Only a QA Engineer can move this task to DONE.");
            } else if (loggedInUser instanceof QAEngineer && !task.getStatus().equals(TaskStatus.READY_FOR_TEST.name()) && newStatus.equals(TaskStatus.DONE.name())) {
                System.out.println("Task must be in READY_FOR_TEST to be moved to DONE.");
            }
        }
    }

    // Method to update the bug status, this is done the same way as the task
    public void updateBugStatus(Sprint sprint, WorkItem workItem, String newStatus) {
        if (workItem instanceof Bug) {
            Bug bug = (Bug) workItem;
            User loggedInUser = UserService.getLoggedInUser();

            if (loggedInUser == null) {
                System.out.println("You must be logged in to update bug status.");
                return;
            }

            if (bug.getAssignedUser() == loggedInUser && loggedInUser instanceof Developer) {
                if (bug.getStatus().equals(BugStatus.TODO.name())) {
                    if (newStatus.equals(BugStatus.IN_PROGRESS.name()) || newStatus.equals(BugStatus.READY_FOR_TEST.name())) {
                        bug.setStatus(newStatus);
                        System.out.println("Bug status updated to " + newStatus + ".");
                    }
                } else if (bug.getStatus().equals(BugStatus.IN_PROGRESS.name())) {
                    if (newStatus.equals(BugStatus.READY_FOR_TEST.name())) {
                        bug.setStatus(BugStatus.READY_FOR_TEST.name());
                        System.out.println("Bug status updated to READY_FOR_TEST.");
                    }
                }
                //manages each users accessibility to change status
            } else if (loggedInUser instanceof QAEngineer && bug.getStatus().equals(BugStatus.TODO.name()) && newStatus.equals(BugStatus.IN_PROGRESS.name())) {
                System.out.println("Only a Developer can move this bug from TODO to IN_PROGRESS.");
            } else if (loggedInUser instanceof Developer && bug.getStatus().equals(BugStatus.READY_FOR_TEST.name()) && newStatus.equals(BugStatus.DONE.name())) {
                System.out.println("Only a QA Engineer can move this bug to DONE.");
            } else if (loggedInUser instanceof QAEngineer && !bug.getStatus().equals(BugStatus.READY_FOR_TEST.name()) && newStatus.equals(BugStatus.DONE.name())) {
                System.out.println("Bug must be in READY_FOR_TEST to be moved to DONE.");
            }
        }
    }

    // Method to add a team member to the sprint, it is called later in the add workitem method but we are keeping private as the user wont need to call it
    private void addTeamMember(Sprint sprint, User user) {
        if (!UserService.isUserLoggedIn()) {
            System.out.println("You must be logged in to add a team member.");
            return;
        }

        if (sprint == null) {
            System.out.println("Sprint cannot be null.");
            return;
        }

        if (user != null && !sprint.getTeamMembers().contains(user)) {
            sprint.getTeamMembers().add(user);
            System.out.println(user.getName() + " has been added to the sprint team.");
        } else {
            System.out.println("User is either null or already in the sprint team.");
        }
    }

    // Method to display team members in the sprint
    public void displayTeamMembers(Sprint sprint) {
        if (sprint == null) return;

        System.out.println("Users in the sprint:");
        for (int i = 0; i < sprint.getTeamMembers().size(); i++) {
            User member = sprint.getTeamMembers().get(i);
            System.out.println(member.getName() + " - " + member.getRole());
        }
    }

    // Method to display work items in the sprint
    public void displaySprintWorkItems(Sprint sprint) {
        if (sprint == null) return;

        System.out.println("Work items in the sprint:");

        for (int i = 0; i < sprint.getTasks().size(); i++) {
            Task task = sprint.getTasks().get(i);
            System.out.println("Task: " + task.getTitle() + " - Status: " + task.getStatus());
        }

        for (int i = 0; i < sprint.getBugs().size(); i++) {
            Bug bug = sprint.getBugs().get(i);
            System.out.println("Bug: " + bug.getTitle() + " - Status: " + bug.getStatus());
        }

        for (int i = 0; i < sprint.getStories().size(); i++) {
            Story story = sprint.getStories().get(i);
            System.out.println("Story: " + story.getTitle() + " - Status: " + story.getStatus());
        }

        for (int i = 0; i < sprint.getEpics().size(); i++) {
            Epic epic = sprint.getEpics().get(i);
            System.out.println("Epic: " + epic.getTitle() + " - Status: " + epic.getStatus());
        }
    }

    // Method to add work item to sprint
    public void addWorkItemToSprint(Sprint sprint, WorkItem workItem) {
        if (workItem instanceof Task) {
            sprint.getTasks().add((Task) workItem);
            System.out.println("Task added to sprint.");
        } else if (workItem instanceof Bug) {
            sprint.getBugs().add((Bug) workItem);
            System.out.println("Bug added to sprint.");
        } else if (workItem instanceof Epic) {
            sprint.getEpics().add((Epic) workItem);
            System.out.println("Epic added to sprint.");
        } else if (workItem instanceof Story) {
            sprint.getStories().add((Story) workItem);
            System.out.println("Story added to sprint.");
        }

        addTeamMember(sprint, workItem.getAssignedUser());
    }
}
