package com.agiletool.service;

import com.agiletool.entity.user.*;
import com.agiletool.entity.workitem.WorkItem;
import com.agiletool.database.Database;

public class UserService {
    private static User loggedInUser = null;

    // Register a new user and return the User object instead of a boolean
    public User registerUser(String name, String email, String password, String role) {

        // Check if the user already exists by email
        for (int i = 0; i < Database.users.size(); i++) {
            User user = Database.users.get(i);
            if (user.getEmail().equals(email)) {
                return null;  // Return null if the email is already registered
            }
        }

        // Continue with your existing logic...

        User newUser = null;

        if (role.equals("ScrumMaster")) {
            newUser = new ScrumMaster(name, email, password);
        } else if (role.equals("Developer")) {
            newUser = new Developer(name, email, password);
        } else if (role.equals("QA")) {
            newUser = new QAEngineer(name, email, password);
        } else if (role.equals("Stakeholder")) {
            newUser = new Stakeholder(name, email, password);
        }

        if (newUser != null) {
            Database.addUser(newUser);  // Assign ID + add to database
        }

        return newUser;
    }


    // Login functionality
    public boolean loginUser(String email, String password) {

        // Loop through users to find the matching email and password
        for (int i = 0; i < Database.users.size(); i++) {
            User user = Database.users.get(i);

            if (user.getEmail().equals(email)) {

                if (user.checkPassword(password)) {
                    loggedInUser = user;  // Set logged-in user if password matches
                    return true;          // Successfully logged in
                }

                return false;  // Email found but password incorrect
            }
        }

        return false;  // No user found with this email
    }


    // Get logged-in user
    public static User getLoggedInUser() {
        return loggedInUser;
    }

    // Check if a user is logged in
    public static boolean isUserLoggedIn() {
        return loggedInUser != null;
    }

    // Logout
    public static void logout() {
        loggedInUser = null; // Clear logged-in user
    }

    // Display work items assigned to a user
    public void displayUserWorkItems(User user) {
        if (user == null || user.getWorkItems().isEmpty()) {
            System.out.println(user.getName() + " has no work items assigned.");
            return;
        }

        System.out.println(user.getName() + "'s Work Items:");

        // Iterate over the work items using normal loop
        for (int i = 0; i < user.getWorkItems().size(); i++) {
            WorkItem workItem = user.getWorkItems().get(i);

            String workItemType = workItem.getWorkItemType();  // Task, Bug, etc.
            String workItemTitle = workItem.getTitle();
            String workItemStatus = workItem.getStatus();

            System.out.println("- " + workItemType + ": " + workItemTitle + " - Status: " + workItemStatus);
        }
    }


    // Method to check the user's password
    public boolean checkPassword(String passwordToCheck) {
        if (this.loggedInUser == null) {
            System.out.println("No user is logged in.");
            return false;
        }
        return this.loggedInUser.getPassword().equals(passwordToCheck);
    }

    // Method to assign a work item to a user (with validation)
    public boolean assignWorkItemToUser(WorkItem workItem) {
        if (!isUserLoggedIn()) {
            System.out.println("You must be logged in to assign a work item.");
            return false;
        }

        User loggedInUser = getLoggedInUser();

        // ScrumMasters, Developers, or QA Engineers can assign work items
        if (!(loggedInUser instanceof ScrumMaster || loggedInUser instanceof Developer || loggedInUser instanceof QAEngineer)) {
            System.out.println("Only ScrumMasters, Developers, or QA Engineers can assign work items.");
            return false;
        }

        // Check if the assigned user is a valid Developer or QA Engineer
        if (!(workItem.getAssignedUser() instanceof Developer || workItem.getAssignedUser() instanceof QAEngineer)) {
            System.out.println("Only Developers or QA Engineers can be assigned work items.");
            return false;
        }

        // Assign the work item to the user
        workItem.assignToUser(loggedInUser);
        System.out.println(workItem.getTitle() + " assigned to " + loggedInUser.getName());
        return true;
    }
}
